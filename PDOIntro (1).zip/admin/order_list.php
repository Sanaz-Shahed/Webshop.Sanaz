<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <table>
        <thead>
            <tr>
                <th>orderID</th>
                <th>unique_code</th>
                <th>shipperID</th>
                <th>customerID</th>
                <th>sum</th>
                <th>date</th>
            </tr>
        </thead>
        <tbody id="tbody">

        </tbody>
    </table>
    <button id="order_getAll">Order List</button>

    <script src="assets/js/main.js"></script>
    <script>
        document.getElementById("order_getAll").addEventListener("click", getAllOrders)
        async function getAllOrders() {
            alert('hi')
            const action = "getAll";
            let allProducts = await makeRequest(`../receivers/orderReceiver.php?action=${action}`, "GET")
            for (const x in allProducts){

            }
            console.log(allProducts)
        }

    </script>
</body>
</html>