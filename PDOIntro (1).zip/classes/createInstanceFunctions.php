<?php

include_once("./../classes/product.php");

function createProduct($id, $name, $price, $description) {
    return new Product((int)$id, $name, $price, $description);
} 

?>