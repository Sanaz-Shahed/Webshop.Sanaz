<?php

class Order {
    public $orderID;
    public $unique_code;
    public $shipperID;
    public $customerID;

    function __construct($orderID, $unique_code, $shipperID, $customerID) {
        $this->orderID = $orderID;
        $this->unique_code = $unique_code;
        $this->shipperID = $shipperID;
        $this->customerID = $customerID;
    }
}

?>