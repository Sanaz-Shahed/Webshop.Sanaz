<?php 

include_once("./../classes/createInstanceFunctions.php");
include_once("./../controllers/mainController.php");


class OrderController extends MainController {

    private $createFunction = "createProduct";

    function __construct() {
        parent::__construct("Orders", "Order");
    }

    public function getAll() {
        return $this->database->fetchAll($this->createFunction);
    }

    public function getById($id) {
        return $this->database->fetchById($id, $this->createFunction);
    }

    public function add($product) {
        try {

            $producToAdd = createProduct(null, $product->name, $product->price, $product->description);
            return $this->database->insert($producToAdd);

        } catch(Exception $e) {
            throw new Exception("The product is not in correct format...", 500);
        }
    }

    public function delete($id) {
        return $this->database->delete($id);
    }


}


?>